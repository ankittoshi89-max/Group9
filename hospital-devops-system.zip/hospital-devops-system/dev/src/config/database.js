class Database {
  connect() {
    console.log("Database connected (simulated)");
  }
}

module.exports = new Database();