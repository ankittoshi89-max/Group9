const User = require("./auth.model");
const authService = require("./auth.service");

class AuthController {
  register(req, res) {
    const { username, role } = req.body;
    const user = new User(username, role);
    res.json(authService.registerUser(user));
  }

  login(req, res) {
    res.json(authService.loginUser(req.body.username));
  }
}
module.exports = new AuthController();