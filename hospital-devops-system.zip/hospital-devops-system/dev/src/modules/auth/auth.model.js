class User {
  constructor(username, role) {
    this.username = username;
    this.role = role;
  }
}
module.exports = User;