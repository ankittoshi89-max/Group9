class AuthService {
  registerUser(user) {
    return { message: "User registered", user };
  }
  loginUser(username) {
    return { token: "FAKE-JWT-TOKEN", username };
  }
}
module.exports = new AuthService();