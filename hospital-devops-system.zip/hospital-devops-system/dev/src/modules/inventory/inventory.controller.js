const service = require("./inventory.service");

class InventoryController {
  async add(req, res) {
    const item = await service.addItem(req.body);
    res.json(item);
  }

  async list(req, res) {
    const items = await service.listItems();
    res.json(items);
  }
}

module.exports = new InventoryController();