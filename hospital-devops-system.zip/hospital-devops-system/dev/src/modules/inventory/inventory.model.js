const mongoose = require("mongoose");

class InventoryModel {
  static schema() {
    return new mongoose.Schema({
      itemName: String,
      quantity: Number,
      category: String
    });
  }
}