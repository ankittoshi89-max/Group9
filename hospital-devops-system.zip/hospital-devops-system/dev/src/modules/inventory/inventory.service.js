const Inventory = require("./inventory.model");

class InventoryService {
  async addItem(data) {
    return Inventory.create(data);
  }

  async listItems() {
    return Inventory.find();
  }
}

module.exports = new InventoryService();