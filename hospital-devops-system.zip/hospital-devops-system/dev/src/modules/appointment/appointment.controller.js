const service = require("./appointment.service");

class AppointmentController {
  async book(req, res) {
    const appt = await service.book(req.body);
    res.json(appt);
  }

  async list(req, res) {
    const appts = await service.list();
    res.json(appts);
  }
}

module.exports = new AppointmentController();