const Appointment = require("./appointment.model");

class AppointmentService {
  async book(data) {
    return Appointment.create(data);
  }

  async list() {
    return Appointment.find().populate("patientId doctorId");
  }
}

module.exports = new AppointmentService(); 