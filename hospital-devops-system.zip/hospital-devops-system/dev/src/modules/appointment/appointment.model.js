const mongoose = require("mongoose");

class AppointmentModel {
  static schema() {
    return new mongoose.Schema({
      patientId: { type: mongoose.Schema.Types.ObjectId, ref: "Patient" },
      doctorId: { type: mongoose.Schema.Types.ObjectId, ref: "Doctor" },
      date: Date,
      status: { type: String, default: "scheduled" }
    });
  }
}

module.exports = mongoose.model("Appointment", AppointmentModel.schema());