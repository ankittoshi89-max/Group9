const express = require("express");
const router = express.Router();
const controller = require("./appointment.controller");

router.post("/", controller.book);
router.get("/", controller.list);

module.exports = router;   