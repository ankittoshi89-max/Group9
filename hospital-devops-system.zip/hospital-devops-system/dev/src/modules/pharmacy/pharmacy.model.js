const mongoose = require("mongoose");

class PharmacyModel {
  static schema() {
    return new mongoose.Schema({
      medicineName: { type: String, required: true },
      stock: { type: Number, default: 0 },
      price: Number,
      expiryDate: Date
    });
  }
}

module.exports = mongoose.model("Pharmacy", PharmacyModel.schema());