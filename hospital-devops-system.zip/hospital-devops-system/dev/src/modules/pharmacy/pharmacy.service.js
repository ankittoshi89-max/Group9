const Pharmacy = require("./pharmacy.model");

class PharmacyService {
  async addMedicine(data) {
    // Just add the new medicine to the database
    return Pharmacy.create(data);
  }

  async listMedicines() {
    // Grab all the medicines from the database
    return Pharmacy.find();
  }
}

module.exports = new PharmacyService();