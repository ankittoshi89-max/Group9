const express = require("express");
const router = express.Router();
const controller = require("./pharmacy.controller");

router.post("/", controller.add);
router.get("/", controller.list);

module.exports = router;