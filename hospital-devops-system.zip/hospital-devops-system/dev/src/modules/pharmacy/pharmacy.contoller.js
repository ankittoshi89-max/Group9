const service = require("./pharmacy.service");

class PharmacyController {
  async add(req, res) {
    const med = await service.addMedicine(req.body);
    res.json(med);
  }

  async list(req, res) {
    const meds = await service.listMedicines();
    res.json(meds);
  }
}

module.exports = new PharmacyController();