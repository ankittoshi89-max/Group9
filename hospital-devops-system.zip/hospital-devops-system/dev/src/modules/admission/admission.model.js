class Admission {
  constructor(patientName, wardNumber) {
    this.patientName = patientName;
    this.wardNumber = wardNumber;
    this.date = new Date();
  }
}

module.exports = Admission;