const Admission = require("./admission.model");
const service = require("./admission.service");

class AdmissionController {
  admit(req, res) {
    const { patientName, wardNumber } = req.body;
    const admission = new Admission(patientName, wardNumber);
    const result = service.admitPatient(admission);
    res.json(result);
  }
}

module.exports = new AdmissionController();