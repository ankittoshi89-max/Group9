const express = require("express")
const controller = require("./admission.controller")
const router = express.Router()

router.post("/admit", controller.admit)

module.exports = router