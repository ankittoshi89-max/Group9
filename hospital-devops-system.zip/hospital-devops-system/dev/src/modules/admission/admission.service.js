class AdmissionService {
  admitPatient(admission) {
    return {
      message: "Patient’s been admitted to the ward.",
      admission
    };
  }
}

module.exports = new AdmissionService();