const service = require("./report.service");

class ReportController {
  async summary(req, res) {
    const data = await service.summary();
    res.json(data);
  }
}

module.exports = new ReportController();