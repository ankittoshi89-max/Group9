const Patient = require("../patient/patient.model");
const Appointment = require("../appointment/appointment.model");

class ReportService {
  async summary() {
    const patients = await Patient.countDocuments();
    const appointments = await Appointment.countDocuments();
    return {
      patients,
      appointments
    };
  }
}

module.exports = new ReportService();