const express = require("express");
const router = express.Router();
const controller = require("./report.controller");

router.get("/summary", controller.summary);

module.exports = router;