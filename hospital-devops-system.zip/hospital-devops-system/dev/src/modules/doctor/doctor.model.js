const mongoose = require("mongoose");

class DoctorModel {
  static schema() {
    return new mongoose.Schema({
      name: { type: String, required: true },
      specialization: { type: String, required: true },
      email: { type: String, unique: true },
      phone: String,
      createdAt: { type: Date, default: Date.now }
    });
  }
}

module.exports = mongoose.model("Doctor", DoctorModel.schema());