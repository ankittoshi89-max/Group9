const Doctor = require("./doctor.model");

class DoctorService {
  async createDoctor(data) {
    return Doctor.create(data);
  }

  async getDoctors() {
    return Doctor.find();
  }

  async getDoctorById(id) {
    return Doctor.findById(id);
  }

  async deleteDoctor(id) {
    return Doctor.findByIdAndDelete(id);
  }
}

module.exports = new DoctorService();