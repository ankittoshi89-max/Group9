const doctorService = require("./doctor.service");

class DoctorController {
  async create(req, res) {
    const doctor = await doctorService.createDoctor(req.body);
    res.json(doctor);
  }

  async list(req, res) {
    const doctors = await doctorService.getDoctors();
    res.json(doctors);
  }

  async get(req, res) {
    const doctor = await doctorService.getDoctorById(req.params.id);
    res.json(doctor);
  }

  async remove(req, res) {
    await doctorService.deleteDoctor(req.params.id);
    res.json({ message: "Doctor removed" });
  }
}

module.exports = new DoctorController();