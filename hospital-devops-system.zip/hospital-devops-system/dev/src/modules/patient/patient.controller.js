const Patient = require("./patient.model");
const service = require("./patient.service");

class PatientController {
  register(req, res) {
    const { name, age, gender } = req.body;
    const patient = new Patient(name, age, gender);
    const addedPatient = service.addPatient(patient);
    res.json(addedPatient);
  }

  list(req, res) {
    const patients = service.listPatients();
    res.json(patients);
  }
}

module.exports = new PatientController();