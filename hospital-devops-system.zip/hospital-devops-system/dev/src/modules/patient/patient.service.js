class PatientService {
  addPatient(patient) {
    return {
      message: "All set. Patient registered.",
      patient
    };
  }

  listPatients() {
    return ["Patient A", "Patient B"];
  }
}

module.exports = new PatientService();