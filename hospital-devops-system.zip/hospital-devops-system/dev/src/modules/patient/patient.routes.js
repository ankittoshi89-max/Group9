const express = require("express");
const controller = require("./patient.controller");
const router = express.Router();

router.post("/register", controller.register);
router.get("/list", controller.list);

module.exports = router;