class BillingService {
  async createBill(data) {
    return await Billing.create(data);
  }

  async listBills() {
    return await Billing.find().populate("patientId");
  }
}

module.exports = new BillingService();