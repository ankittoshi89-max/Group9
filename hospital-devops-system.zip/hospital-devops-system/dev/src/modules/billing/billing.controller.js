const service = require("./billing.service");

class BillingController {
  async create(req, res) {
    try {
      const bill = await service.createBill(req.body);
      res.json(bill);
    } catch (err) {
      res.status(500).json({ error: "Couldn’t create the bill." });
    }
  }

  async list(req, res) {
    try {
      const bills = await service.listBills();
      res.json(bills);
    } catch (err) {
      res.status(500).json({ error: "Couldn’t fetch bills." });
    }
  }
}

module.exports = new BillingController();