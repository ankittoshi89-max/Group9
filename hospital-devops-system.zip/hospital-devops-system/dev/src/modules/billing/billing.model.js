const mongoose = require("mongoose");

class BillingModel {
  static schema() {
    return new mongoose.Schema({
      patientId: { type: mongoose.Schema.Types.ObjectId, ref: "Patient" },
      amount: Number,
      description: String,
      paid: { type: Boolean, default: false },
      createdAt: { type: Date, default: Date.now }
    });
  }
}

module.exports = mongoose.model("Billing", BillingModel.schema());