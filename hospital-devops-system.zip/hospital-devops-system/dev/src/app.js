// app.js
const express = require("express");
const dotenv = require("dotenv");
const Database = require("./config/database");

// Import Routes (9 modules)
const authRoutes = require("./modules/auth/auth.routes");
const patientRoutes = require("./modules/patient/patient.routes");
const admissionRoutes = require("./modules/admission/admission.routes");
const doctorRoutes = require("./modules/doctor/doctor.routes");
const appointmentRoutes = require("./modules/appointment/appointment.routes");
const billingRoutes = require("./modules/billing/billing.routes");
const pharmacyRoutes = require("./modules/pharmacy/pharmacy.routes");
const inventoryRoutes = require("./modules/inventory/inventory.routes");
const reportRoutes = require("./modules/report/report.routes");

dotenv.config();

class App {
  constructor() {
    this.app = express();
    this.initializeMiddlewares();
    this.initializeDatabase();
    this.initializeRoutes();
  }

  initializeMiddlewares() {
    this.app.use(express.json());
  }

  initializeDatabase() {
    Database.connect();
  }

  initializeRoutes() {
    this.app.use("/api/auth", authRoutes);
    this.app.use("/api/patients", patientRoutes);
    this.app.use("/api/admissions", admissionRoutes);
    this.app.use("/api/doctors", doctorRoutes);
    this.app.use("/api/appointments", appointmentRoutes);
    this.app.use("/api/billing", billingRoutes);
    this.app.use("/api/pharmacy", pharmacyRoutes);
    this.app.use("/api/inventory", inventoryRoutes);
    this.app.use("/api/reports", reportRoutes);
  }
}

module.exports = new App().app;git